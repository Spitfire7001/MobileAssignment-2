package com.example.assignment2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LocationAdapter.OnItemClickListener{

    RecyclerView recyclerView;
    LocationAdapter locationAdapter;
    ArrayList<Location> locationList;
    DBHelper myDB;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        searchView = findViewById(R.id.searchBox);
        recyclerView = findViewById(R.id.recyclerView);
        myDB = new DBHelper(this);
        locationList = new ArrayList<>();

        loadLocations();
        locationAdapter = new LocationAdapter(locationList, this);
        recyclerView.setAdapter(locationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchLocationsByAddress(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                searchLocationsByAddress(query);
                return true;
            }
        });
    }

    public void loadLocations() {
        Cursor cursor = myDB.getAllLocations();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String address = cursor.getString(1);
                double longitude = cursor.getDouble(2);
                double latitude = cursor.getDouble(3);

                Location location = new Location(id, address, longitude, latitude);
                locationList.add(location);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public void searchLocationsByAddress(String query) {
        Cursor cursor = myDB.searchLocationsByAddress(query);
        locationList.clear();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String address = cursor.getString(1);
                double longitude = cursor.getDouble(2);
                double latitude = cursor.getDouble(3);

                Location location = new Location(id, address, longitude, latitude);
                locationList.add(location);
            } while (cursor.moveToNext());
        }
        cursor.close();
        locationAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDeleteClick(int position) {
        Location location = locationList.get(position);
        myDB.deleteLocation(location.getId());
        locationList.remove(position);
        locationAdapter.notifyItemRemoved(position);
        Toast.makeText(this, "Location deleted", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpdateClick(int position) {
        Location location = locationList.get(position);
        Intent i = new Intent(this, UpdateLocationActivity.class);
        i.putExtra("location_id", location.getId());
        i.putExtra("address_name", location.getAddress());
        i.putExtra("longitude", location.getLongitude());
        i.putExtra("latitude", location.getLatitude());
        startActivity(i);
    }

    public void launchAddLocationActivity(View v) {
        Intent i = new Intent(this, AddLocationActivity.class);
        startActivity(i);
    }
}