package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateLocationActivity extends AppCompatActivity {

    EditText inputAddress, inputLongitude, inputLatitude;
    private DBHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_location);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        myDB = new DBHelper(this);
        inputAddress = findViewById(R.id.locationAddressInput);
        inputLongitude = findViewById(R.id.locationLongitudeInput);
        inputLatitude = findViewById(R.id.locationLatitudeInput);

        inputAddress.setText(getIntent().getStringExtra("address_name"));
        inputLongitude.setText(Double.toString(getIntent().getDoubleExtra("longitude",-1)));
        inputLatitude.setText(Double.toString(getIntent().getDoubleExtra("latitude",-1)));
    }

    public void updateLocation(View v) {
        try {
            int locationId = getIntent().getIntExtra("location_id", -1);
            String address = inputAddress.getText().toString().trim();
            double longitude = Double.parseDouble(inputLongitude.getText().toString().trim());
            double latitude = Double.parseDouble(inputLatitude.getText().toString().trim());
            myDB.updateLocation(locationId,address,longitude,latitude);

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        } catch (NumberFormatException e){
            Toast.makeText(this, "Please fill all fields properly", Toast.LENGTH_SHORT).show();
        }
    }

    public void launchMainActivity(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}