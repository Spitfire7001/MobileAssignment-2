package com.example.assignment2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {
    private List<Location> locationList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(int position);
        void onUpdateClick(int position);
    }

    public static class LocationViewHolder extends RecyclerView.ViewHolder {
        public TextView address;
        public TextView longitude;
        public TextView latitude;
        public Button deleteButton;
        public Button updateButton;

        public LocationViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            address = itemView.findViewById(R.id.location_address);
            longitude = itemView.findViewById(R.id.location_longitude);
            latitude = itemView.findViewById(R.id.location_latitude);
            deleteButton = itemView.findViewById(R.id.button_delete);
            updateButton = itemView.findViewById(R.id.button_update);

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onDeleteClick(getAdapterPosition());
                }
            });

            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onUpdateClick(getAdapterPosition());
                }
            });
        }
    }

    public LocationAdapter(List<Location> locationList, OnItemClickListener listener) {
        this.locationList = locationList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.location_item, parent, false);
        return new LocationViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        Location location = locationList.get(position);
        holder.address.setText(location.getAddress());
        holder.longitude.setText("Longitude: " + location.getLongitude());
        holder.latitude.setText("Latitude: " + location.getLatitude());
    }

    @Override
    public int getItemCount() {
        return locationList.size();
    }
}

