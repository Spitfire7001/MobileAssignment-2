package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddLocationActivity extends AppCompatActivity {

    EditText inputAddress, inputLongitude, inputLatitude;
    private DBHelper myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_location);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        myDB = new DBHelper(this);
        inputAddress = findViewById(R.id.locationAddressInput);
        inputLongitude = findViewById(R.id.locationLongitudeInput);
        inputLatitude = findViewById(R.id.locationLatitudeInput);
    }

    public void storeLocation(View v) {
        try {
            String address = inputAddress.getText().toString().trim();
            double longitude = Double.parseDouble(inputLongitude.getText().toString().trim());
            double latitude = Double.parseDouble(inputLatitude.getText().toString().trim());
            myDB.addLocation(address,longitude,latitude);

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        } catch (NumberFormatException e){
            Toast.makeText(this, "Please fill all fields properly", Toast.LENGTH_SHORT).show();
        }
    }

    public void launchMainActivity(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}